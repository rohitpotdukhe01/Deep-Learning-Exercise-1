class BaseLayer:
    def _init_(self):
        self.trainable = False
        self.weight = None
